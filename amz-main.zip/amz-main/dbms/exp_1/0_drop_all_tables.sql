DROP TABLE musician;
DROP TABLE instrument;
DROP TABLE musician_instrument;
DROP TABLE album;
DROP TABLE song;
DROP TABLE musician_song;
