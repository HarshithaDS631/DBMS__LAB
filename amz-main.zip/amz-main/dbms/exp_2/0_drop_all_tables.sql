DROP TABLE doctor;

DROP TABLE patient;

DROP TABLE doctor_patient_check;

DROP TABLE drug;

DROP TABLE doctor_drug_prescribe;

DROP TABLE pharmacy;

DROP TABLE drug_pharmacy_sell;

DROP TABLE phar_company;

DROP TABLE phar_comp_pharmacy_contract;




