INSERT INTO vendor
VALUES
	(1, "Shubash vendors", "Bangalore", "459875621"),
	(2, "Namaste vendors", "Mysore", "8745986325"),
	(3, "Polar vendors", "Mangalore", "5478965325"),
	(4, "Hola vendors", "Mysore", "6589745896");
	

INSERT INTO panel
VALUES
	(1, "Monocrystalline", 15, 4000000, 2000),
	(2, "Polycrystalline", 10, 4000000, 3000),
	(3, "Monocrystalline", 15, 8000000, 1000),
	(4, "Polycrystalline", 10, 5000000, 800),
	(5, "Monocrystalline", 15, 5000000, 12001),
	(6, "Polycrystalline", 10, 3000000, 21211),
	(7, "Monocrystalline", 15, 2000000, 1000),
	(8, "Polycrystalline", 10, 8000000, 300),
	(9, "Monocrystalline", 15, 2000000, 1000),
	(10, "Polycrystalline", 10, 8000000, 900),
	(11, "Monocrystalline", 15, 9000000, 600),
	(12, "Polycrystalline", 10, 7000000, 400);

INSERT INTO user
VALUES
	(1, "Bangalore", "Domestic"),
	(2, "Mysore", "Commercial"),
	(3, "Bangalore", "Domestic"),
	(4, "Mysore", "Commercial"),
	(5, "Bangalore", "Domestic"),
	(6, "Mysore", "Commercial"),
	(7, "Bangalore", "Domestic"),
	(8, "Mysore", "Commercial"),
	(9, "Bangalore", "Domestic"),
	(10, "Mysore", "Commercial"),
	(11, "Bangalore", "Domestic"),
	(12, "Mysore", "Commercial");
	
INSERT INTO install
VALUES
	(1, 1, 1, "10-11-10"),
	(1, 2, 1, "11-11-10"),
	(1, 1, 2, "12-11-10"),
	(2, 1, 3, "13-11-10"),
	(2, 2, 2, "14-11-10"),
	(3, 2, 3, "15-11-10"),
	(4, 2, 4, "16-11-10"),
	(5, 2, 5, "17-11-10");

INSERT INTO sell
VALUES
	(1, 1),
	(1, 2),
	(2, 2),
	(2, 3),
	(2, 4);
	


	
	
	
	
	
	
	
	
	
	
	
	
	
	
