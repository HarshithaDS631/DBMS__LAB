DESC vendor;

DESC panel;

DESC user;

DESC install;

DESC sell;

DESC purchase;
