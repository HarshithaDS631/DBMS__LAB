DROP TABLE vendor;

DROP TABLE panel;

DROP TABLE user;

DROP TABLE install;

DROP TABLE sell;

DROP TABLE purchase;
